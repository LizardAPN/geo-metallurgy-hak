## The nickel market outlook - can the laterite revolution continue?

July 2013

Jim Lennon

Consultant to:

Macquarie Capital Securities (Europe) Ltd

+44 203 037 4271

jim.lennon@macquarie.com

In preparing this research, we did not take into account the investment objectives, financial situation and particular needs of the reader. Before making an investment decision on the basis of this research, the reader needs to consider, with or without the assistance of an adviser, whether the advice is appropriate in light of their particular investment needs, objectives and financial circumstances. Please see disclaimer.

## The changing face of the nickel market

-  Huge needs for new capacity driven by explosion in Chinese demand since 2000
-  Nickel shortage up to 2006/07 led to three responses:
-  Growth in 200-series stainless steel (1-2% Ni) as a substitute for 300-series (8-9% Ni)
-  Processing of low-grade laterite nickel ores into nickel pig iron in China
-  $30bn+ spent by non-Chinese industry to expand production (including New Caledonia)
-  In the face of declining sulphide reserves, solution to growth was mainly from using low-grade laterites (limonites) by pressure acid leach processes (PAL) or from highergrade laterites (saprolites) using conventional ferronickel smelting.
-  Soaring capex and major technical challenges have made this 'solution' economically unviable in the eyes of the industry.
-  The 'new' solution has been the development of low-capex/high opex nickel pig iron (NPI) in China.
-  Main questions for the market are: Economics of NPI now and into the future - when does this end?; What are the economics of the alternatives? Will we revert back to PAL/FeNi 'solution' or there alternatives (e.g., low grade sulphides?).

## Take-off of Chinese demand stretched the nickel supply chain to breaking point in 2006/07

Source: LME, Antaike, Macquarie Research, July 2013

## Nickel demand growth is all about China

Source: INSG, ISSF, Macquarie Research, July 2013

## World Ex-China has not recovered from 2008 global financial crisis

Source: ISSF, Macquarie Research, July 2013

## Stainless steel production by region ('000t SS)

| | 2007 | 2012 | %change |
|------------------------|--------|--------|-----------|
| China | 7108 | 16000 | 125% |
| Asia w/o China | 9387 | 8875 | -5% |
| W.Europe/Africa | 8017 | 7329 | -9% |
| Americas | 2694 | 2369 | -12% |
| Central+Eastern Europe | 333 | 362 | 9% |
| World ex-China | 20431 | 18935 | -7% |
| World | 27539 | 34936 | 27% |

## Primary nickel supply has also been all about China since 2008 - surge in supply too much for market

Source: INSG, Macquarie Research, July 2013

## The short term - still awful with more cuts needed - LME stocks up 51kt in 2012 and 46kt in 2013 YTD

Source: LME, Antaike, Macquarie Research, July 2013

## Need for new nickel capacity - subdued in 2000-10 mainly by use of 200 series stainless, but lots of supply growth now needed

Source: INSG, CSSC, Macquarie Research, July 2013

- Major surge in nickel use from 2000-2006 driven mainly by china
- Shortage of nickel prompted switch to 200series stainless in China
- Collapse in global demand in 2009, combined with substitution led to major deceleration in demand growth
- Past three years has seen surging demand (and supply) once again

## Chinese found two ways of avoiding an absolute shortage of nickel after 2007

Source: ISSF, CSSC, Macquarie Research, July 2013

## The changing face of nickel - stagnation in sulphide production as laterites take off - mine production basis

Source: INSG, Macquarie Research, July 2013

New Caledonia has not participated in the laterite ore surge

## The growing role of Indonesia and the Philippines

Mine production overstates the actual impact due to massive ore stocking in China and also &gt;50% of ore from Philippines not being used as nickel, but iron ore

Source: Philippines Mines and Geosciences Bureau, INSG, GTIS, Macquarie Research, July 2013

## The picture on type of ores used in finished nickel production shows a major shift up in laterites

Source: Company data, INSG, Macquarie Research, July 2013

## Current main production processes for nickel

Source: INSG, Macquarie Research, July 2013

Note: excludes leaching processes for sulphides (Talvivaara bioleach in Finland) and limonites (in Guangxi and Jiangshi in China)

## Our estimates and forecasts of nickel production by process route

Source: Company data, INSG, Macquarie Research, July 2013

## Laterite growth dominated by FeNi, PAL and NPI

Source: Company data, INSG, Macquarie Research, July 2013

-  Much of major sulphide mine investment over past 20 years (Voisey's Bay, Raglan, Nickel Rim, Mount Keith, Cosmos, Santa Rita, Flying Fox, Nkomati, Lanfranci, FNX, Kevista, etc) was essentially defensive, to offset falling reserves elsewhere.
-  New mines such as Enterprise, Dumont, etc, will help replace ongoing reserve depletions.
-  Growth in laterites has come mainly from conventional ferronickel, high-pressure acid leach and Chinese nickel pig iron.
-  Still further scope for growth in Indonesia, Korea and China (latter two with help of New Caledonian ore?).

## Where the finished nickel supply growth has come from and could come from

| '000t Ni | Level 1990 | Level 2000 | Level 2012 | Level 2017F* |
|-------------------------------------|--------------|--------------|--------------|----------------|
| Sulphide - conventional | 658 | 692 | 769 | 829 |
| Sulphide bioheapleach | 0 | 0 | 13 | 25 |
| Laterite - ferronickel | 178 | 209 | 333 | 493 |
| Laterite - nickel pig iron | 0 | 0 | 351 | 370 |
| Laterite - Caron | 48 | 83 | 82 | 81 |
| Laterite - PAL | 20 | 53 | 142 | 319 |
| Other laterite (leach&smelt/refine) | 40 | 70 | 82 | 104 |
| Total | 944 | 1108 | 1772 | 2221 |
| %share | %share | %share | %share | %share |
| | 1990 | 2000 | 2012 | 2017F |
| Sulphide - conventional | 70% | 62% | 43% | 37% |
| Sulphide bioheapleach | 0% | 0% | 1% | 1% |
| Laterite - ferronickel | 19% | 19% | 19% | 22% |
| Laterite - nickel pig iron | 0% | 0% | 20% | 17% |
| Laterite - Caron | 5% | 8% | 5% | 4% |
| Laterite - PAL | 2% | 5% | 8% | 14% |
| Other laterite (leach&smelt/refine) | 4% | 6% | 5% | 5% |
| Total | 100% | 100% | 100% | 100% |

* 2017f forecast is before disruption allowance

Source: Company data, INSG, Macquarie Research, July 2013

## Strong growth ahead for FeNi and PAL…but that has been the case for some time now!

Source: Company data, INSG, Macquarie Research, July 2013

## Stainless industry getting lots more nickel and (mainly free) iron units now

Source: Company data, INSG, Macquarie Research, July 2013

## NPI accounted for major share of nickel used in China in 2012 - replacement for scrap use in ROW

Source: INSG, Macquarie Research, July 2013

## Main recent PAL and FeNi projects - late and expensive

| PAL | | '000tpa | $m | | | | Ferronickel | '000tpa $m | '000tpa $m | '000tpa $m |
|------------------------|----------|-----------|-------|---------|------------|----------|----------------------|-------------------|--------------|--------------|
| | Start-up | Capacity | Capex | $/t cap | Acid plant | Refinery | | Start-up Capacity | Capex | $/t cap |
| Murrin Murrin | 1999 | 40 | 1700 | 42500 | x | x | Gwangywang | 2008 30 | 720 | 24000 |
| Coral Bay Stage 1 | 2005 | 12 | 220 | 18333 | | | Onca Puma | 2011 52 | 3200 | 61538 |
| Ravensthorpe original | 2007 | 40 | 3000 | 75000 | x | x | Barro Alto | 2011 40 | 1900 | 47500 |
| VNC (Goro) | 2010 | 60 | 6000 | 100000 | x | x | Koniambo | 2013 60 | 5500 | 91667 |
| Ramu | 2012 | 32 | 1800 | 56250 | x | | Taguang Taung Nickel | 2012 22 | 850 | 38636 |
| Ambatovy | 2012 | 60 | 5500 | 91667 | x | x | | | | |
| Taganito | 2013 | 30 | 1600 | 53333 | | | | | | |
| Total above | | 274 | 19820 | 72336 | | | Total above | 204 | 12170 | 59657 |
| Ravensthorpe reopening | 2011 | 40 | 740 | 18500 | | | | | | |

- Projects running many years late, capex mostly rose 2-4 times above original estimates and commissioning problems have been major
- Too early to be precise on operating costs but we think the PAL projects will range from $8,000-15,000/t with an average of $12-13,000/t while the ferronickel projects range from $8,500-13,000/t with an average of $10,000/t. Opex estimates much higher than in feasibility.

Source: Company data, INSG, Macquarie Research, July 2013

## Nickel pig iron progress by contrast has been miraculous!

This is a very rough guide to the economics of new capacity

Source: Company data, Wood Mackenzie, Macquarie Research, July 2013

## Long run prices need to be higher…depending on NPI!

Source: Wood Mackenzie, Macquarie Research, May 2012

## Nickel pig iron - the big unknown

-  Estimates for 2012 output (still!) vary from 290kt to 370kt - very little reporting, lots of guessing.
-  Cash costs range from $12-20,000/tonne ($5.45-9/lb) depending on process and location. Costs vary widely.
-  Costs do vary with nickel price so there is no single price below which supply shuts indeed costs have fallen sharply (15-20%) since March 2012 (lower carbon and ore prices and new power rebates in Inner Mongolia).
-  Capacity potential is massive - OVER 400,000 tpa NEW capacity due, mostly Greenfield rotary kiln/electric arc furnace and integrated with stainless mills. Costs will rise as energy prices rise and RMB appreciates but new plants have 30-50% less energy consumption and stainless mills get significant energy and iron credit benefits.
-  Ore supplies from Philippines and Indonesia are critical in determining the future output limits. Many Chinese producers trying to backwardly integrate into ore.
-  If new supply outside China comes on successfully, capping prices, NPI production will be limited - if new supply fails, there will be more NPI.

## Lots of new rotary kiln electric furnace (RKEF) capacity coming on stream in 2013!

Source: Industry estimates, Macquarie Research, July 2013

Shangai Haihe

Tsingshan

Changqing

Beihai Chengde

Ningbo Wanxiang

Delong Nieye

## Ore, carbon and electricity main cost drivers for NPI - 2012 averages

Source: Industry estimates, Macquarie Research, July 2013

NPI costs for electric furnace producers - big differences in costs according to location and furnace types - costs fall as raw material and power costs fall

Source: SMM, Macquarie Research, July 2013

## Low Ni NPI blast furnace producers still profitable

Source: SMM, Macquarie Research, July 2013

## Cost of ore from Indonesia has plunged in 2013

Source: NPI producers, Macquarie Research, July 2013

## Key factors in NPI

-  Indonesian ore ban planned for end-2013. No-one thinks this will happen! Quotas and taxes more likely? 20% export tax (adds 35-40c/lb to costs if passed on…but it was not!) from May 2012…maybe higher?
-  Longer term cost pressures - breakeven for NPI could rise from $12,00017,000/t currently to $19,000-25,000/lb over next 4-5 years as ore costs, electricity costs rise and RMB appreciates?
-  Competition for higher-grade ore (1.8%+Ni) will intensify as more RKEF comes on and high grade reserves deplete - price of these ores could rise sharply.
-  Still unclear how long the resources can last at current rates.
-  We don't think ore supply from Indonesia to China will stop in 2014 - it will become (a lot) more expensive and there will probably be some NPI capacity built in Indonesia from 2015 onwards.

## Nickel supply/demand summary - surplus to 2015?

| `000t | 2011 | 2012 | 2013f | 2014f | 2015f | 2016f | 2017f | 2018f |
|---------------------------|--------|--------|---------|---------|---------|---------|---------|---------|
| Total SS production | 33666 | 35440 | 38045 | 40458 | 43077 | 45581 | 47748 | 49737 |
| %Change | 5.7% | 5.3% | 7.4% | 6.3% | 6.5% | 5.8% | 4.8% | 4.2% |
| Ni-containing SS prod. | 25080 | 26831 | 28707 | 30523 | 32632 | 34510 | 35986 | 37564 |
| %Change | 9.3% | 7.0% | 7.0% | 6.3% | 6.9% | 5.8% | 4.3% | 4.4% |
| Nickel Consumption | 1597 | 1669 | 1771 | 1861 | 1968 | 2055 | 2108 | 2165 |
| %Change | 7.4% | 4.5% | 6.2% | 5.1% | 5.7% | 4.5% | 2.5% | 2.7% |
| Nickel Supply | 1630 | 1772 | 1843 | 1938 | 1986 | 2042 | 2065 | 2090 |
| %Change | 12.3% | 8.7% | 4.0% | 5.1% | 2.5% | 2.8% | 1.1% | 1.2% |
| (of which NPI) | (282) | (351) | (396) | (378) | (360) | (360) | (360) | (360) |
| World Market Balance | 33 | 103 | 72 | 77 | 18 | -14 | -43 | -75 |
| LME/Producer stocks | 186 | 227 | 299 | 375 | 394 | 380 | 338 | 262 |
| Weeks' world demand | 5.9 | 6.9 | 8.6 | 10.3 | 10.2 | 9.4 | 8.2 | 6.2 |
| LME Cash Price (cents/lb) | 1036 | 795 | 746 | 817 | 953 | 1134 | 1300 | 1400 |
| LME Cash Price ($/tonne) | 22831 | 17527 | 16455 | 18001 | 21001 | 25000 | 28660 | 30864 |

Source: INSG, Macquarie Research, July 2013

## In conclusion - on the medium term

-  The laterite 'revolution' has arrived - it is built on the shaky ground of low-cost Indonesian ore/Chinese NPI and VERY high-cost non-Chinese PAL/FeNi capacity
-  Failure of major Greenfield projects outside China and massive rises in construction costs of non-Chinese Greenfield projects likely to deter future investment
-  Next two years will be challenging for the nickel industry - unless the Indonesians ban ore exports in 2014
-  Growing deficits by mid-decade will lead to need for new capacity…new capacity needs prices significantly above $22,000/t ($10/lb)
-  Huge reliance on Indonesian ore to feed RFEF plants in China - unlikely to stay as 'cheap' as it is today?

## Important disclosures:

## Recommendation definitions

## Macquarie - Australia/New Zealand

Outperform - return &gt; 3% in excess of benchmark return Neutral - return within 3% of benchmark return Underperform - return &gt; 3% below benchmark return

Benchmark return is determined by long term nominal GDP growth plus 12 month forward market dividend yield

## Macquarie - Asia/Europe

Outperform - expected return &gt;+10% Neutral - expected return from -10% to +10% Underperform - expected &lt;-10%

## Macquarie First South - South Africa

Outperform - return &gt; 10% in excess of benchmark return Neutral - return within 10% of benchmark return Underperform - return &gt; 10% below benchmark return

## Macquarie - Canada

Outperform - return &gt; 5% in excess of benchmark return Neutral - return within 5% of benchmark return Underperform - return &gt; 5% below benchmark return

## Macquarie - USA

Outperform - return &gt; 5% in excess of benchmark return Neutral - return within 5% of benchmark return Underperform - return &gt; 5% below benchmark return

## Volatility index definition*

This is calculated from the volatility of historic price movements.

Very high-highest risk - Stock should be expected to move up or down 60-100% in a year - investors should be aware this stock is highly speculative.

High - stock should be expected to move up or down at least 40-60% in a year - investors should be aware this stock could be speculative.

Medium - stock should be expected to move up or down at least 30-40% in a year.

Low-medium - stock should be expected to move up or down at least 25-30% in a year.

Low - stock should be expected to move up or down at least 15-25% in a year.

* Applicable to Australian/NZ stocks only

Recommendation - 12 months

Note: Quant recommendations may differ from Fundamental Analyst recommendations

## Financial definitions

All "Adjusted" data items have had the following adjustments made:

Added back : goodwill amortisation, provision for catastrophe reserves, IFRS derivatives &amp; hedging, IFRS impairments &amp; IFRS interest expense

Excluded: non recurring items, asset revals, property revals, appraisal value uplift, preference dividends &amp; minority interests

EPS

= adjusted net profit /efpowa*

ROA = adjusted ebit / average total assets

ROA Banks/Insurance

= adjusted net profit /average total

assets

ROE = adjusted net profit / average shareholders funds Gross cashflow = adjusted net profit + depreciation *equivalent fully paid ordinary weighted average number of shares

All Reported numbers for Australian/NZ listed stocks are modelled under IFRS (International Financial Reporting Standards).

## Recommendation proportions - For quarter ending 31 March 2013

| | AU/NZ | Asia | RSA | USA | CA | EUR |
|--------------|---------|--------|--------|--------|--------|--------------------------------------------------------------------------------------------|
| Outperform | 45.12% | 53.24% | 50.00% | 40.70% | 62.98% | 43.30% (for US coverage by MCUSA, 10.55% of stocks covered are investment banking clients) |
| Neutral | 41.52% | 28.01% | 41.43% | 55.01% | 32.60% | 34.10% (for US coverage by MCUSA, 9.05% of stocks covered are investment banking clients) |
| Underperform | 13.36% | 18.74% | 8.57% | 4.29% | 4.42% | 22.60% (for US coverage by MCUSA, 0.00% of stocks covered are investment banking clients) |

## Company Specific Disclosures:

Important disclosure information regarding the subject companies covered in this report is available at www.macquarie.com/research/disclosures.

## Analyst Certification:

The views expressed in this research accurately reflect the personal views of the analyst(s) about the subject securities or issuers and no part of the compensation of the analyst(s) was, is, or will be directly or indirectly related to the inclusion of specific recommendations or views in this research. The analyst principally responsible for the preparation of this research receives compensation based on overall revenues of Macquarie Group Ltd ABN 94 122 169 279 (AFSL No. 318062) (MGL) and its related entities (the Macquarie Group) and has taken reasonable care to achieve and maintain independence and objectivity in making any recommendations.

## General Disclaimers:

Macquarie Securities (Australia) Ltd; Macquarie Capital (Europe) Ltd; Macquarie Capital Markets Canada Ltd; Macquarie Capital Markets North America Ltd; Macquarie Capital (USA) Inc; Macquarie Capital Securities Ltd and its Taiwan branch; Macquarie Capital Securities (Singapore) Pte Ltd; Macquarie Securities (NZ) Ltd; and Macquarie First South Securities (Pty) Limited; Macquarie Capital Securities (India) Pvt Ltd; Macquarie Capital Securities (Malaysia) Sdn Bhd; Macquarie Securities Korea Limited and Macquarie Securities (Thailand) Ltd are not authorized deposit-taking institutions for the purposes of the Banking Act 1959 (Commonwealth of Australia), and their obligations do not represent deposits or other liabilities of Macquarie Bank Limited ABN 46 008 583 542 (MBL) or MGL. MBL does not guarantee or otherwise provide assurance in respect of the obligations of any of the above mentioned entities. MGL provides a guarantee to the Monetary Authority of Singapore in respect of the obligations and liabilities of Macquarie Capital Securities (Singapore) Pte Ltd for up to SGD 35 million. This research has been prepared for the general use of the wholesale clients of the Macquarie Group and must not be copied, either in whole or in part, or distributed to any other person. If you are not the intended recipient you must not use or disclose the information in this research in any way. If you received it in error, please tell us immediately by return e-mail and delete the document. We do not guarantee the integrity of any e-mails or attached files and are not responsible for any changes made to them by any other person. MGL has established and implemented a conflicts policy at group level (which may be revised and updated from time to time) (the "Conflicts Policy") pursuant to regulatory requirements (including the FSA Rules) which sets out how we must seek to identify and manage all material conflicts of interest. Nothing in this research shall be construed as a solicitation to buy or sell any security or product, or to engage in or refrain from engaging in any transaction. In preparing this research, we did not take into account your investment objectives, financial situation or particular needs. Before making an investment decision on the basis of this research, you need to consider, with or without the assistance of an adviser, whether the advice is appropriate in light of your particular investment needs, objectives and financial circumstances. There are risks involved in securities trading. The price of securities can and does fluctuate, and an individual security may even become valueless. International investors are reminded of the additional risks inherent in international investments, such as currency fluctuations and international stock market or economic conditions, which may adversely affect the value of the investment. This research is based on information obtained from sources believed to be reliable but we do not make any representation or warranty that it is accurate, complete or up to date. We accept no obligation to correct or update the information or opinions in it. Opinions expressed are subject to change without notice. No member of the Macquarie Group accepts any liability whatsoever for any direct, indirect, consequential or other loss arising from any use of this research and/or further communication in relation to this research. Clients should contact analysts at, and execute transactions through, a Macquarie Group entity in their home jurisdiction unless governing law permits otherwise.

Disclaimer: The information contained in this e-mail is confidential and has been furnished to you solely for your use. You may not disclose, reproduce or distribute the information in any way. Macquarie does not guarantee the integrity of this e-mail or attached files.

Macquarie Capital (USA) Inc. affiliate research reports and affiliate employees are not subject to the disclosure requirements of FINRA rules. Any persons receiving this report directly from Macquarie Capital (USA) Inc. and wishing to effect a transaction in any security described herein should do so with Macquarie Capital (USA) Inc. In Germany, this research is issued and/or distributed by Macquarie Capital (Europe) Limited, Niederlassung Deutschland, which is authorised and regulated by the UK Financial Services Authority and in Germany by BaFin.

Macquarie salespeople, traders and other professionals may provide oral or written market commentary or trading strategies to our clients that reflect opinions which are contrary to the opinions expressed in this research. Macquarie Research produces a variety of research products including, but not limited to, fundamental analysis, macro-economic analysis, quantitative analysis, and trade ideas. Recommendations contained in one type of research product may differ from recommendations contained in other types of research, whether as a result of differing time horizons, methodologies, or otherwise.

## Country-Specific Disclaimers:

Australia : In Australia, research is issued and distributed by Macquarie Securities (Australia) Ltd (AFSL No. 238947), a participating organisation of the Australian Securities Exchange. New Zealand : In New Zealand, research is issued and distributed by Macquarie Securities (NZ) Ltd, a NZX Firm. Canada : In Canada, research is prepared, approved and distributed by Macquarie Capital Markets Canada Ltd, a participating organisation of the Toronto Stock Exchange, TSX Venture Exchange &amp; Montréal Exchange. Macquarie Capital Markets North America Ltd., which is a registered broker-dealer and member of FINRA, accepts responsibility for the contents of reports issued by Macquarie Capital Markets Canada Ltd in the United States and sent to US persons. Any person wishing to effect transactions in the securities described in the reports issued by Macquarie Capital Markets Canada Ltd should do so with Macquarie Capital Markets North America Ltd. The Research Distribution Policy of Macquarie Capital Markets Canada Ltd is to allow all clients that are entitled to have equal access to our research. United Kingdom : In the United Kingdom, research is issued and distributed by Macquarie Capital (Europe) Ltd, which is authorised and regulated by the Financial Services Authority (No. 193905). Germany : In Germany, research is issued and distributed by Macquarie Capital (Europe) Ltd, Niederlassung Deutschland, which is authorised and regulated in the United Kingdom by the Financial Services Authority (No. 193905). France : In France, research is issued and distributed by Macquarie Capital (Europe) Ltd, which is authorised and regulated in the United Kingdom by the Financial Services Authority (No. 193905). Hong Kong &amp; Mainland China : In Hong Kong, research is issued and distributed by Macquarie Capital Securities Ltd, which is licensed and regulated by the Securities and Futures Commission. In Mainland China, Macquarie Securities (Australia) Limited Shanghai Representative Office only engages in non-business operational activities excluding issuing and distributing research. Only non-A share research is distributed into Mainland China by Macquarie Capital Securities Ltd. Japan : In Japan, research is Issued and distributed by Macquarie Capital Securities (Japan) Limited, a member of the Tokyo Stock Exchange, Inc., Osaka Securities Exchange Co. Ltd. (Financial Instruments Firm, Kanto Financial Bureau (kin-sho) No. 231, a member of Japan Securities Dealers Association and The Financial Futures Association of Japan and Japan Investment Advisers Association). India: In India, research is issued and distributed by Macquarie Capital Securities (India) Pty Ltd., 92, Level 9, 2 North Avenue, Maker Maxity, Bandra Kurla Complex, Bandra (East), Mumbai - 400 051, India, which is a SEBI registered Stock Broker having membership with National Stock Exchange of India Limited (INB231246738) and Bombay Stock Exchange Limited (INB011246734). Malaysia : In Malaysia, research is issued and distributed by Macquarie Capital Securities (Malaysia) Sdn. Bhd. (Company registration number: 463469-W) which is a Participating Organisation of Bursa Malaysia Berhad and a holder of Capital Markets Services License issued by the Securities Commission. Taiwan : Information on securities/instruments that are traded in Taiwan is distributed by Macquarie Capital Securities Ltd, Taiwan Branch, which is licensed and regulated by the Financial Supervisory Commission. No portion of the report may be reproduced or quoted by the press or any other person without authorisation from Macquarie. Nothing in this research shall be construed as a solicitation to buy or sell any security or product. Research Associate(s) in this report who are registered as Clerks only assist in the preparation of research and are not engaged in writing the research. Thailand : In Thailand, research is produced with the contribution of Kasikorn Securities Public Company Limited, issued and distributed by Macquarie Securities (Thailand) Ltd. Macquarie Securities (Thailand) Ltd. is a licensed securities company that is authorized by the Ministry of Finance, regulated by the Securities and Exchange Commission of Thailand and is an exchange member of the Stock Exchange of Thailand. Macquarie Securities (Thailand) Limited and Kasikorn Securities Public Company Limited have entered into an exclusive strategic alliance agreement to broaden and deepen the scope of services provided to each parties respective clients. The strategic alliance does not constitute a joint venture. The Thai Institute of Directors Association has disclosed the Corporate Governance Report of Thai Listed Companies made pursuant to the policy of the Securities and Exchange Commission of Thailand. Macquarie Securities (Thailand) Ltd does not endorse the result of the Corporate Governance Report of Thai Listed Companies but this Report can be accessed at: http://www.thai-iod.com/en/publications.asp?type=4. South Korea : In South Korea, unless otherwise stated, research is prepared, issued and distributed by Macquarie Securities Korea Limited , which is regulated by the Financial Supervisory Services. Information on analysts in MSKL is disclosed at http://dis.kofia.or.kr/fs/dis2/fundMgr/DISFundMgrAnalystPop.jsp?companyCd2=A03053&amp;pageDiv=02.

South Africa : In South Africa, research is issued and distributed by Macquarie First South Securities (Pty) Limited, a member of the JSE Limited. Singapore : In Singapore, research is issued and distributed by Macquarie Capital Securities (Singapore) Pte Ltd (Company Registration Number: 198702912C), a Capital Markets Services license holder under the Securities and Futures Act to deal in securities and provide custodial services in Singapore. Pursuant to the Financial Advisers (Amendment) Regulations 2005, Macquarie Capital Securities (Singapore) Pte Ltd is exempt from complying with sections 25, 27 and 36 of the Financial Advisers Act. All Singapore-based recipients of research produced by Macquarie Capital (Europe) Limited, Macquarie Capital Markets Canada Ltd, Macquarie First South Securities (Pty) Limited and Macquarie Capital (USA) Inc. represent and warrant that they are institutional investors as defined in the Securities and Futures Act. United States : In the United States, research is issued and distributed by Macquarie Capital (USA) Inc., which is a registered broker-dealer and member of FINRA. Macquarie Capital (USA) Inc, accepts responsibility for the content of each research report prepared by one of its non-US affiliates when the research report is distributed in the United States by Macquarie Capital (USA) Inc. Macquarie Capital (USA) Inc.'s affiliate's analysts are not registered as research analysts with FINRA, may not be associated persons of Macquarie Capital (USA) Inc., and therefore may not be subject to FINRA rule restrictions on communications with a subject company, public appearances, and trading securities held by a research analyst account. Information regarding futures is provided for reference purposes only and is not a solicitation for purchases or sales of futures. Any persons receiving this report directly from Macquarie Capital (USA) Inc. and wishing to effect a transaction in any security described herein should do so with Macquarie Capital (USA) Inc. Important disclosure information regarding the subject companies covered in this report is available at www.macquarie.com/research/disclosures, or contact your registered representative at 1888-MAC-STOCK, or write to the Supervisory Analysts, Research Department, Macquarie Securities, 125 W.55th Street, New York, NY 10019.

© Macquarie Group